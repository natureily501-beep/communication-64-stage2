# 64期甲班 第二階段 V3 Pro

## Netlify 上傳方式
1. 解壓縮 ZIP。
2. 到 Netlify → Add new site → Deploy manually。
3. 把整個資料夾拖上去。
4. 產生網址後，用 iPhone Safari 開啟。

## GitHub Pages
把 `index.html`, `questions.js`, `manifest.webmanifest` 放到 repository 根目錄，啟用 Pages。
